import { PostCard } from '@/components/post-card';
import { Pagination } from '@/components/pagination';
import { LoadingSpinner } from '@/components/loading-spinner';
import { usePosts } from '@/context/posts-context';
import { Eye, Database, Smartphone, RefreshCw, Inbox } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Posts() {
  const { state, dispatch } = usePosts();
  const { displayedPosts, currentPage, totalPages, allPosts, postsPerPage, isLoading, error } = state;

  const startPost = (currentPage - 1) * postsPerPage + 1;
  const endPost = Math.min(currentPage * postsPerPage, allPosts.length);

  const handleRetry = () => {
    window.location.reload();
  };

  if (isLoading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <header className="bg-card border-b border-border shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between">
              <h1 className="text-3xl font-semibold text-foreground">Posts Dashboard</h1>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col items-center justify-center py-16">
            <div className="bg-destructive/10 rounded-full p-6 mb-4">
              <RefreshCw className="w-8 h-8 text-destructive" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">Failed to load posts</h3>
            <p className="text-muted-foreground text-center max-w-md mb-4" data-testid="text-error-message">
              {error}
            </p>
            <Button onClick={handleRetry} data-testid="button-retry">
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry
            </Button>
          </div>
        </main>
      </div>
    );
  }

  if (allPosts.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <header className="bg-card border-b border-border shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between">
              <h1 className="text-3xl font-semibold text-foreground">Posts Dashboard</h1>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col items-center justify-center py-16">
            <div className="bg-muted/30 rounded-full p-6 mb-4">
              <Inbox className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">No posts available</h3>
            <p className="text-muted-foreground text-center max-w-md mb-4">
              We couldn't find any posts to display. Please check your connection or try refreshing the page.
            </p>
            <Button onClick={handleRetry} data-testid="button-retry">
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry
            </Button>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-semibold text-foreground" data-testid="text-page-title">
              Posts Dashboard
            </h1>
            <div className="flex items-center space-x-2 text-muted-foreground">
              <i className="fas fa-list-alt text-lg"></i>
              <span className="text-sm font-medium" data-testid="text-total-posts">
                {allPosts.length} Posts
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Bar */}
        <div className="bg-card rounded-lg border border-border p-4 mb-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Eye className="w-4 h-4 text-primary" />
                <span className="text-sm text-muted-foreground">Showing</span>
                <span className="text-sm font-semibold text-foreground" data-testid="text-start-post">
                  {startPost}
                </span>
                <span className="text-sm text-muted-foreground">-</span>
                <span className="text-sm font-semibold text-foreground" data-testid="text-end-post">
                  {endPost}
                </span>
                <span className="text-sm text-muted-foreground">of</span>
                <span className="text-sm font-semibold text-foreground" data-testid="text-total-posts-stats">
                  {allPosts.length}
                </span>
                <span className="text-sm text-muted-foreground">posts</span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">Page</span>
              <span className="text-sm font-semibold text-primary" data-testid="text-current-page">
                {currentPage}
              </span>
              <span className="text-sm text-muted-foreground">of</span>
              <span className="text-sm font-semibold text-foreground" data-testid="text-total-pages">
                {totalPages}
              </span>
            </div>
          </div>
        </div>

        {/* Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-8" data-testid="grid-posts">
          {displayedPosts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>

        {/* Pagination */}
        <Pagination />
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-muted-foreground text-sm">
            <p>Data fetched from <strong>JSONPlaceholder API</strong> • Built with React & Context</p>
            <div className="flex items-center justify-center space-x-4 mt-2">
              <span className="flex items-center space-x-1">
                <Database className="w-3 h-3" />
                <span>Real-time data</span>
              </span>
              <span className="text-xs">•</span>
              <span className="flex items-center space-x-1">
                <Smartphone className="w-3 h-3" />
                <span>Responsive design</span>
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
