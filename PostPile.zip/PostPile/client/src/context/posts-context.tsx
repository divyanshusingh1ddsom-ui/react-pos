import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { Post } from '@/types/post';

interface PostsState {
  allPosts: Post[];
  displayedPosts: Post[];
  currentPage: number;
  postsPerPage: number;
  isLoading: boolean;
  error: string | null;
  totalPages: number;
}

type PostsAction =
  | { type: 'SET_POSTS'; payload: Post[] }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'SET_PAGE'; payload: number }
  | { type: 'REMOVE_POST'; payload: number }
  | { type: 'UPDATE_DISPLAYED_POSTS' };

const initialState: PostsState = {
  allPosts: [],
  displayedPosts: [],
  currentPage: 1,
  postsPerPage: 6,
  isLoading: true,
  error: null,
  totalPages: 0,
};

function postsReducer(state: PostsState, action: PostsAction): PostsState {
  switch (action.type) {
    case 'SET_POSTS':
      const totalPages = Math.ceil(action.payload.length / state.postsPerPage);
      const startIndex = (state.currentPage - 1) * state.postsPerPage;
      const endIndex = startIndex + state.postsPerPage;
      return {
        ...state,
        allPosts: action.payload,
        displayedPosts: action.payload.slice(startIndex, endIndex),
        totalPages,
        isLoading: false,
        error: null,
      };
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload, isLoading: false };
    case 'SET_PAGE':
      const newPage = action.payload;
      const newStartIndex = (newPage - 1) * state.postsPerPage;
      const newEndIndex = newStartIndex + state.postsPerPage;
      return {
        ...state,
        currentPage: newPage,
        displayedPosts: state.allPosts.slice(newStartIndex, newEndIndex),
      };
    case 'REMOVE_POST':
      const filteredPosts = state.allPosts.filter(post => post.id !== action.payload);
      const newTotalPages = Math.ceil(filteredPosts.length / state.postsPerPage);
      let adjustedCurrentPage = state.currentPage;
      
      // If current page would be empty, go to previous page
      if (adjustedCurrentPage > newTotalPages && newTotalPages > 0) {
        adjustedCurrentPage = newTotalPages;
      }
      
      const adjustedStartIndex = (adjustedCurrentPage - 1) * state.postsPerPage;
      const adjustedEndIndex = adjustedStartIndex + state.postsPerPage;
      
      return {
        ...state,
        allPosts: filteredPosts,
        displayedPosts: filteredPosts.slice(adjustedStartIndex, adjustedEndIndex),
        currentPage: adjustedCurrentPage,
        totalPages: newTotalPages,
      };
    case 'UPDATE_DISPLAYED_POSTS':
      const updateStartIndex = (state.currentPage - 1) * state.postsPerPage;
      const updateEndIndex = updateStartIndex + state.postsPerPage;
      return {
        ...state,
        displayedPosts: state.allPosts.slice(updateStartIndex, updateEndIndex),
      };
    default:
      return state;
  }
}

interface PostsContextType {
  state: PostsState;
  dispatch: React.Dispatch<PostsAction>;
  goToPage: (page: number) => void;
  removePost: (postId: number) => void;
  goToNextPage: () => void;
  goToPreviousPage: () => void;
}

const PostsContext = createContext<PostsContextType | undefined>(undefined);

export function PostsProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(postsReducer, initialState);

  const fetchPosts = async () => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      // Show loading for 5 seconds as requested
      await new Promise(resolve => setTimeout(resolve, 5000));
      
      const response = await fetch('https://jsonplaceholder.typicode.com/posts');
      
      if (!response.ok) {
        throw new Error(`Failed to fetch posts: ${response.status} ${response.statusText}`);
      }
      
      const posts: Post[] = await response.json();
      dispatch({ type: 'SET_POSTS', payload: posts });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to fetch posts';
      dispatch({ type: 'SET_ERROR', payload: errorMessage });
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  const goToPage = (page: number) => {
    if (page >= 1 && page <= state.totalPages) {
      dispatch({ type: 'SET_PAGE', payload: page });
    }
  };

  const removePost = (postId: number) => {
    dispatch({ type: 'REMOVE_POST', payload: postId });
  };

  const goToNextPage = () => {
    if (state.currentPage < state.totalPages) {
      goToPage(state.currentPage + 1);
    }
  };

  const goToPreviousPage = () => {
    if (state.currentPage > 1) {
      goToPage(state.currentPage - 1);
    }
  };

  const value: PostsContextType = {
    state,
    dispatch,
    goToPage,
    removePost,
    goToNextPage,
    goToPreviousPage,
  };

  return (
    <PostsContext.Provider value={value}>
      {children}
    </PostsContext.Provider>
  );
}

export function usePosts() {
  const context = useContext(PostsContext);
  if (context === undefined) {
    throw new Error('usePosts must be used within a PostsProvider');
  }
  return context;
}
