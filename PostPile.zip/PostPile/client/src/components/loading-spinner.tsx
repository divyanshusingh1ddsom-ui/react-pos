export function LoadingSpinner() {
  return (
    <div className="flex flex-col items-center justify-center py-20">
      <div className="loading-spinner mb-4"></div>
      <p className="text-muted-foreground text-lg font-medium">Loading posts...</p>
      <p className="text-muted-foreground text-sm mt-2">Please wait while we fetch the latest content</p>
    </div>
  );
}
