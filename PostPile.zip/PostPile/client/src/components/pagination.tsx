import { ChevronLeft, ChevronRight } from 'lucide-react';
import { usePosts } from '@/context/posts-context';
import { Button } from '@/components/ui/button';

export function Pagination() {
  const { state, goToPage, goToNextPage, goToPreviousPage } = usePosts();
  const { currentPage, totalPages } = state;

  const getVisiblePages = () => {
    const pages: (number | string)[] = [];
    const maxVisible = 5;
    
    if (totalPages <= maxVisible) {
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      if (currentPage <= 3) {
        pages.push(1, 2, 3, '...', totalPages);
      } else if (currentPage >= totalPages - 2) {
        pages.push(1, '...', totalPages - 2, totalPages - 1, totalPages);
      } else {
        pages.push(1, '...', currentPage - 1, currentPage, currentPage + 1, '...', totalPages);
      }
    }
    
    return pages;
  };

  if (totalPages <= 1) return null;

  return (
    <div className="bg-card rounded-lg border border-border p-6 shadow-sm">
      <div className="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
        
        <Button
          onClick={goToPreviousPage}
          disabled={currentPage === 1}
          variant="outline"
          className="flex items-center space-x-2"
          data-testid="button-previous-page"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Previous</span>
        </Button>

        <div className="flex items-center space-x-2">
          {getVisiblePages().map((page, index) => (
            <div key={index}>
              {typeof page === 'number' ? (
                <Button
                  onClick={() => goToPage(page)}
                  variant={currentPage === page ? "default" : "outline"}
                  size="sm"
                  className="w-10 h-10"
                  data-testid={`button-page-${page}`}
                >
                  {page}
                </Button>
              ) : (
                <span className="text-muted-foreground px-2" data-testid="text-pagination-ellipsis">
                  {page}
                </span>
              )}
            </div>
          ))}
        </div>

        <Button
          onClick={goToNextPage}
          disabled={currentPage === totalPages}
          variant="outline"
          className="flex items-center space-x-2"
          data-testid="button-next-page"
        >
          <span>Next</span>
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>

      <div className="mt-4 pt-4 border-t border-border sm:hidden">
        <div className="flex items-center justify-center space-x-2">
          <label htmlFor="page-input" className="text-sm text-muted-foreground">Go to page:</label>
          <input
            type="number"
            id="page-input"
            min="1"
            max={totalPages}
            value={currentPage}
            onChange={(e) => {
              const page = parseInt(e.target.value);
              if (page >= 1 && page <= totalPages) {
                goToPage(page);
              }
            }}
            className="w-16 px-2 py-1 text-sm border border-border rounded text-center focus:ring-2 focus:ring-primary focus:border-primary"
            data-testid="input-page-number"
          />
        </div>
      </div>
    </div>
  );
}
