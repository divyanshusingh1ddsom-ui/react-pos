import { Post } from '@/types/post';
import { X, ArrowRight, Clock, User } from 'lucide-react';
import { usePosts } from '@/context/posts-context';

interface PostCardProps {
  post: Post;
}

export function PostCard({ post }: PostCardProps) {
  const { removePost } = usePosts();

  const handleRemove = () => {
    removePost(post.id);
  };

  const getReadingTime = (text: string) => {
    const wordsPerMinute = 200;
    const wordCount = text.split(' ').length;
    const minutes = Math.ceil(wordCount / wordsPerMinute);
    return `${minutes} min read`;
  };

  return (
    <div className="post-card bg-card rounded-lg border border-border shadow-sm hover:shadow-md relative overflow-hidden group">
      <button 
        onClick={handleRemove}
        className="remove-btn absolute top-3 right-3 w-8 h-8 bg-white rounded-full shadow-md border border-border flex items-center justify-center z-10 opacity-0 group-hover:opacity-100 transition-all duration-200 hover:bg-destructive hover:border-destructive hover:text-destructive-foreground"
        data-testid={`button-remove-post-${post.id}`}
        aria-label={`Remove post ${post.id}`}
      >
        <X className="w-4 h-4" />
      </button>
      
      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <span 
            className="bg-primary/10 text-primary text-xs font-medium px-2.5 py-1 rounded-full"
            data-testid={`text-post-id-${post.id}`}
          >
            #{post.id}
          </span>
          <div className="flex items-center space-x-1 text-muted-foreground text-xs">
            <User className="w-3 h-3" />
            <span data-testid={`text-user-id-${post.id}`}>User {post.userId}</span>
          </div>
        </div>
        
        <h3 
          className="text-lg font-semibold text-foreground mb-3 line-clamp-2"
          data-testid={`text-post-title-${post.id}`}
        >
          {post.title}
        </h3>
        
        <p 
          className="text-muted-foreground text-sm leading-relaxed line-clamp-3 mb-4"
          data-testid={`text-post-body-${post.id}`}
        >
          {post.body}
        </p>
        
        <div className="flex items-center justify-between pt-3 border-t border-border">
          <button 
            className="text-primary hover:text-primary/80 text-sm font-medium transition-colors flex items-center gap-1"
            data-testid={`button-read-more-${post.id}`}
          >
            <ArrowRight className="w-4 h-4" />
            Read More
          </button>
          <div className="flex items-center space-x-2 text-muted-foreground text-xs">
            <Clock className="w-3 h-3" />
            <span data-testid={`text-reading-time-${post.id}`}>{getReadingTime(post.body)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
