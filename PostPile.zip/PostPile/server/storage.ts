import { type Post } from "@shared/schema";

// Storage interface for posts application
// Note: This app fetches posts directly from JSONPlaceholder API
// so storage is minimal for this implementation

export interface IStorage {
  // Placeholder for potential future storage needs
}

export class MemStorage implements IStorage {
  constructor() {
    // Minimal storage implementation
  }
}

export const storage = new MemStorage();
